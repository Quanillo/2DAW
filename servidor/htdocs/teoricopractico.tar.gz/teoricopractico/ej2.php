
<?php
    $temp = "String";
    echo $temp;

    echo "<br><br>";

    $temp = 1;
    echo $temp;

    echo "<br><br>";

    $temp = 1.25;
    echo $temp;

    echo "<br><br>";
    
    $temp = array("Esto ", "es ", "un ", "array ", "de ", " Strings.");
    echo $temp[0] . $temp[1] . $temp[2] . $temp[3] . $temp[4] . $temp[5];

    echo "<br><br>";
    //con boolean no lo printea
    $temp = false;
    echo $temp;

?>