<?php
    echo $a;
    print_r(error_get_last()['message']);
?>