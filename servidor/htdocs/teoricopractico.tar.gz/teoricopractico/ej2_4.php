
<?php

    $sueldoPepe = 1300;
    $sueldoJuan = 1500;
    $sueldoDiana = 1200;
    
    echo 
    "<table border='1'>
        <tr>
            <td>Pepe lópez</td>
             <td>".$sueldoPepe . "</td>
        </tr>
        <tr>
            <td>Juan Ortega</td>
            <td>".$sueldoJuan . "</td>
        </tr>
        <tr>
            <td>Diana Montenegro</td>
            <td>".$sueldoDiana."</td>
        </tr>
    </table>";

?>

