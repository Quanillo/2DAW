<?php
    echo '<a href="https://google.com">Google</a>';
?>