<?php
    $date = date_create('2008-09-22');
    $date_timestamp = date_timestamp_get($date);
    echo  $date_timestamp ;
?>