<?php
    $fecha = date_create("2025-10-24");
    echo date_format($fecha, 'd-m-Y ');
?>