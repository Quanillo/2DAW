<?php
    echo isset($_SERVER['HTTPS']) ? 'https' :  'http';
?>