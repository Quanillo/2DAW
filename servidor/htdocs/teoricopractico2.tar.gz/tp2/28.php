<?php
    for($i=0; $i<10; $i++){
        echo pow(2, $i) . '<br>';
    }
?>