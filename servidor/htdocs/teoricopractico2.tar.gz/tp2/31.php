<?php
    for($i = 40; $i<51; $i++){
        echo $i . '<br>';
    }
?>