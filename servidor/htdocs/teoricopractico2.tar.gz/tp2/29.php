<?php
    $num=2;
    for($i=0; $i<10; $i++){
        echo $num . 'x' . $i . '=' . $num*$i . '<br>';
    }
?>