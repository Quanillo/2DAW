<?php
    for($i = 0; $i<101; $i++){
        echo $i . "<br>";
    }
?>