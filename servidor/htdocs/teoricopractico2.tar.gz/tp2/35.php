<?php

    for($j=0; $j<11;$j++){
        echo '<br>';
        for($i=0; $i<11; $i++){
            echo $j . 'x' . $i . '=' . $j*$i . '<br>';
        }
    }
        
?>