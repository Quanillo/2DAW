<?php
    $num1 = rand();$num2 = rand();$num3 = rand();$num4 = rand();$num5 = rand();$num6 = rand();$num7 = rand();$num8 = rand();$num9 = rand();$num10 = rand();
    $media = ($num1 + $num2 + $num3 + $num4 + $num5 + $num6 + $num7 + $num8 + $num9 + $num10)/10;
    echo $num1 .'<br>'. $num2 .'<br>'. $num3 .'<br>'. $num4 .'<br>'. $num5 .'<br>'. $num6 .'<br>'. $num7 .'<br>'. $num8 .'<br>'. $num9 .'<br>'. $num10;
    echo 'Media: ' . $media;
?>