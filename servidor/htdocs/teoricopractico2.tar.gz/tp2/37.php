<?php
    include('fechaEnCastellano.php');
    fechaCastellano();
?>