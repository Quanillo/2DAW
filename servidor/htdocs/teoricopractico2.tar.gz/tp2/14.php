

<?php

    echo "El número de dias de este mes es:  " date('t');
?>