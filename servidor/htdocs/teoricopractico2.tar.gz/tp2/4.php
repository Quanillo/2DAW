<?php

    $time = date('l');
    $time2 = date('dS');
    echo $time . " the " . $time2;

?>