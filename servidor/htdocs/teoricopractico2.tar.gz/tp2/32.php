<?php  
foreach(range('a', 'z') as $letra) {  
  echo $letra;  
}  
?> 