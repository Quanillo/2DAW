<?php
    $time = date('H:i:s');
    echo $time;
    echo "<br>";

    sleep(3);
    
    $time2 = date('H:i:s');
    echo $time2;
?>